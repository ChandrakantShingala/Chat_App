//
//  ChatViewController.swift
//  Chat_App
//
//  Created by Chandrakant shingala on 31/12/24.
//

import UIKit
import MessageKit

struct Sender: SenderType {
    var senderId: String
    var displayName: String
}

struct Message: MessageType {
    var sender: SenderType
    var messageId: String
    var sentDate: Date
    var kind: MessageKind
}

class ChatViewController: MessagesViewController, MessagesDataSource, MessagesDisplayDelegate, MessagesLayoutDelegate {
    
    // MARK: - @IBOutlet's
    
    // MARK: - Variable's
    let currentUser = Sender(senderId: "self", displayName: "Rutvik's IPhone")
    let otherUser = Sender(senderId: "other", displayName: "Bavtik's IPhone")
    var message = [MessageType]()
    
    // MARK: - Life Cycle Method's
    override func viewDidLoad() {
        super.viewDidLoad()
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesDisplayDelegate = self
        messagesCollectionView.messagesLayoutDelegate = self
        self.setupMessages()
    }
    
    private func setupMessages() {
        message.append(Message(sender: currentUser,
                               messageId: "1",
                               sentDate: Date().addingTimeInterval( -86400),
                               kind: .text("Yo! How are you?")))
        message.append(Message(sender: otherUser,
                               messageId: "2",
                               sentDate: Date().addingTimeInterval( -76400),
                               kind: .text("Yo! I am Fine Thanks, What about you?")))
        message.append(Message(sender: currentUser,
                               messageId: "3",
                               sentDate: Date().addingTimeInterval( -66400),
                               kind: .text("I am Fine, Where are you?")))
        message.append(Message(sender: otherUser,
                               messageId: "4",
                               sentDate: Date().addingTimeInterval( -56400),
                               kind: .text("At Home, Why?")))
        message.append(Message(sender: currentUser,
                               messageId: "5",
                               sentDate: Date().addingTimeInterval( -46400),
                               kind: .text("Nah I am Board")))
        message.append(Message(sender: otherUser,
                               messageId: "6",
                               sentDate: Date().addingTimeInterval( -36400),
                               kind: .text("Okay")))
    }
    
    func currentSender() -> any MessageKit.SenderType {
        return currentUser
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessageKit.MessagesCollectionView) -> any MessageKit.MessageType {
        return message[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessageKit.MessagesCollectionView) -> Int {
        return message.count
    }
    

}
