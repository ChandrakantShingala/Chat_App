//
//  ContactViewController.swift
//  Chat_App
//
//  Created by Chandrakant shingala on 31/12/24.
//

import UIKit

class ContactViewController: UIViewController {
    // MARK: - @IBOutlet's
    @IBOutlet weak var ContactTableView: UITableView!
    
    // MARK: - Variable's
    
    // MARK: - Life Cycle Method's
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}

// MARK: - Extension For ContactTableView's Method

extension ContactViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactTableViewCell", for: indexPath) as! ContactTableViewCell
        cell.contactLabel.text = "Rutvik"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let chatVC = storyboard.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
       navigationController?.pushViewController(chatVC, animated: true)
    }
}
