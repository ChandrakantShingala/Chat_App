//
//  Chat_AppTests.swift
//  Chat_AppTests
//
//  Created by Chandrakant shingala on 31/12/24.
//

import Testing
@testable import Chat_App

struct Chat_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
